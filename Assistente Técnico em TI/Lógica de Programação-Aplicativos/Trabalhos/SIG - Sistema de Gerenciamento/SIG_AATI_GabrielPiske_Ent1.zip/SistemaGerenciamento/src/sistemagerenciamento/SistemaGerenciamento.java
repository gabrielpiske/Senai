/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemagerenciamento;

import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.Border;

/**
 *
 * @author gabriel_piske
 */
public class SistemaGerenciamento {


    public static void main(String[] args) {
      FormPrincipal frm = new FormPrincipal();
      
      frm.setSize(600,400);
      
      //Painel com Abas
      JTabbedPane jTbPaneCadastro = new JTabbedPane();
      jTbPaneCadastro.setSize(545,300);
      jTbPaneCadastro.setLocation(20,10);
      
      //Painel Aba Cliente
      JPanel pnlCli = new JPanel();
      pnlCli.setLayout(null);
      
      //Painel Aba Produto
      JPanel pnlProd = new JPanel();
      pnlProd.setLayout(null);
      
      //Painel Aba Fornecedor
      JPanel pnlForn = new JPanel();
      pnlForn.setLayout(null);
      
      //Adicionando os painéis ao Painel com abas
      jTbPaneCadastro.add("Cliente", pnlCli);
      jTbPaneCadastro.add("Produto", pnlProd);
      jTbPaneCadastro.add("Fornecedor", pnlForn);
      
      //Adicionando o painel com Abas no formulario
      frm.add(jTbPaneCadastro);
      
      //Painel com barra de rolagem
      JScrollPane pnlScrlTbCli;
      
      //Tabel da Clientes
      JTable tblCli;
      
      //vetor com os titulos das colunas da tabela
      String[] colTbCli = {"Matricula","Nome", "Telefone", "Email"};
      
      //Vetor com o dados da Tabela
      String [] [] dadosTbCli = {
          {"12345","Ana Silva"           , "47 1111-1111", "anasilva@gmail"},
          {"12345","Paulo Sena"          , "47 2222-2222", "paulo.silva@gmail"},
          {"12567","Carlos Lima"         , "47 3333-3333", "carlos.lima@gmail"},
          {"12098","Paulo Freire"        , "47 4444-4444", "paulo.freire@gmail"},
          {"12274","Helena Catomi"       , "47 5555-5555", "helena.catoni@gmail"},
          {"12196","Diogo Santana"       , "47 6666-6666", "diogo.santana@gmail"},
          {"12968","Glaucia Fernandes"   , "47 7777-7777", "glaucia.fernandes@gmail"},          
          {"12310","João Guilherme"      , "47 8888-8888", "joao.guilherme@gmail"},          
      };
      
      //Preencha a tabela com os dados e nomes das colunas
      tblCli = new JTable(dadosTbCli, colTbCli);
      
      //Adiciona a tabela ao painel de rolagem
      pnlScrlTbCli = new JScrollPane (tblCli);
      
      ///Definições Tamanho, localização e adição
      pnlScrlTbCli.setSize(530,118);
      pnlScrlTbCli.setLocation(5,5);
      pnlCli.add(pnlScrlTbCli);
      
      //////////////////////////////////////////////////////////////////////////
      
      //Criar painel de cadrasto Clientes
      JPanel pnlCadCli = new JPanel();
      pnlCadCli.setSize(530, 135);
      pnlCadCli.setLocation(5, 130);
      
      
      
      //Coloca borda azul no painel
      Border brdBlue = BorderFactory.createLineBorder(Color.blue);
      pnlCadCli.setBorder(brdBlue);
      pnlCadCli.setLayout(null);
      pnlCli.add(pnlCadCli);
      
      //////////////////////////////////////////////////////////////////////////
      
        //Nome
        JLabel jlblNom = new JLabel();
        jlblNom.setSize(160, 15); //definição de tamanho
        jlblNom.setLocation(200,10); //localização
        Font arialBold_16 = new Font("Arial", Font.BOLD, 12);
        jlblNom.setFont(arialBold_16);
        jlblNom.setText("Nome: "); //definição texto
        pnlCadCli.add(jlblNom); //inserindo formulario
        //Entrada Nome
        JTextField jtfNomeD = new JTextField();
        jtfNomeD.setSize(150, 20); //definição de tamanho
        jtfNomeD.setLocation(200,25); //localização
        pnlCadCli.add(jtfNomeD); //inserindo formulario
        
        //Matricula
        JLabel jlblMat = new JLabel();
        jlblMat.setSize(100, 15); //definição de tamanho
        jlblMat.setLocation(10,10); //localização
        jlblMat.setFont(arialBold_16);
        jlblMat.setText("Matricula: "); //definição texto
        pnlCadCli.add(jlblMat); //inserindo formulario
        //Entrada Nome
        JTextField jtfMatriculaD = new JTextField();
        jtfMatriculaD.setSize(150, 20); //definição de tamanho
        jtfMatriculaD.setLocation(10,25); //localização
        pnlCadCli.add(jtfMatriculaD); //inserindo formulario
        
        //Telefone
        JLabel jlblTel = new JLabel();
        jlblTel.setSize(160, 15); //definição de tamanho
        jlblTel.setLocation(10,50); //localização
        jlblTel.setFont(arialBold_16);
        jlblTel.setText("Telefone: "); //definição texto
        pnlCadCli.add(jlblTel); //inserindo formulario
        //Entrada Nome
        JTextField jtfTelefoneD = new JTextField();
        jtfTelefoneD.setSize(150, 20); //definição de tamanho
        jtfTelefoneD.setLocation(10,65); //localização
        pnlCadCli.add(jtfTelefoneD); //inserindo formulario
        
        
        //Email
        JLabel jlblEmail = new JLabel();
        jlblEmail.setSize(100, 15); //definição de tamanho
        jlblEmail.setLocation(200,50); //localização
        jlblEmail.setFont(arialBold_16);
        jlblEmail.setText("Email: "); //definição texto
        pnlCadCli.add(jlblEmail); //inserindo formulario
        //Entrada Nome
        JTextField jtfEmailD = new JTextField();
        jtfEmailD.setSize(145, 20); //definição de tamanho
        jtfEmailD.setLocation(200,65); //localização
        pnlCadCli.add(jtfEmailD); //inserindo formulario
        
        //Apagar
        JButton btnApagar = new JButton(); //criação botão
        btnApagar.setSize(100, 20); //tamanho
        btnApagar.setLocation(400,25); //localização
        btnApagar.setText("Apagar"); //definição texto
        pnlCadCli.add(btnApagar); //inserindo botão
        
        //Salvar
        JButton btnSave = new JButton(); //criação botão
        btnSave.setSize(100, 20); //tamanho
        btnSave.setLocation(400,65); //localização
        btnSave.setText("Salvar"); //definição texto
        pnlCadCli.add(btnSave); //inserindo botão        
        
        
    ///////////////////////////////////////////////////////////////////////////    
        
        ///Produto
                
      //Painel com barra de rolagem
      JScrollPane pnlScrlTbProd;
      
      //Tabel da Clientes
      JTable tblProd;
      
      //vetor com os titulos das colunas da tabela
      String[] colTbProd = {"Código", "Descrição", "Unidade", "Quantidade", "Preço"};
      
      //Vetor com o dados da Tabela
      String [] [] dadosTbProd = {
          {"0001", "Descrição", "Unidade", "Quantidade", "R$1,10"},          
          {"0002", "Descrição", "Unidade", "Quantidade", "R$1,20"},          
          {"0003", "Descrição", "Unidade", "Quantidade", "R$1,30"},          
          {"0004", "Descrição", "Unidade", "Quantidade", "R$1,40"},          
          {"0005", "Descrição", "Unidade", "Quantidade", "R$1,50"},          
          {"0006", "Descrição", "Unidade", "Quantidade", "R$1,60"},          
          {"0007", "Descrição", "Unidade", "Quantidade", "R$1,70"},          
          {"0008", "Descrição", "Unidade", "Quantidade", "R$1,80"},          
      };
      
      //Preencha a tabela com os dados e nomes das colunas
      tblProd = new JTable(dadosTbProd, colTbProd);
      
      //Adiciona a tabela ao painel de rolagem
      pnlScrlTbProd = new JScrollPane (tblProd);
      
      ///Definições Tamanho, localização e adição
      pnlScrlTbProd.setSize(530,118);
      pnlScrlTbProd.setLocation(5,5);
      pnlProd.add(pnlScrlTbProd);
      
      //////////////////////////////////////////////////////////////////////////
      
      //Criar painel de cadrasto Produtos
      JPanel pnlCadProd = new JPanel();
      pnlCadProd.setSize(530, 135);
      pnlCadProd.setLocation(5, 130);
      
      
      
      //Coloca borda azul no painel
      pnlCadProd.setBorder(brdBlue);
      pnlCadProd.setLayout(null);
      pnlProd.add(pnlCadProd);
      
      //////////////////////////////////////////////////////////////////////////
      
        //Código
        JLabel jlblCod = new JLabel();
        jlblCod.setSize(160, 15); //definição de tamanho
        jlblCod.setLocation(10,10); //localização
        jlblCod.setFont(arialBold_16);
        jlblCod.setText("Código: "); //definição texto
        pnlCadProd.add(jlblCod); //inserindo formulario
        //Entrada Codigo
        JTextField jtfCodigoD = new JTextField();
        jtfCodigoD.setSize(150, 20); //definição de tamanho
        jtfCodigoD.setLocation(10,25); //localização
        pnlCadProd.add(jtfCodigoD); //inserindo formulario
        
        
        //Descrição
        JLabel jlblDesc = new JLabel();
        jlblDesc.setSize(160, 15); //definição de tamanho
        jlblDesc.setLocation(10,50); //localização
        jlblDesc.setFont(arialBold_16);
        jlblDesc.setText("Descrição: "); //definição texto
        pnlCadProd.add(jlblDesc); //inserindo formulario
        //Entrada Nome
        JTextField jtfDescricaoD = new JTextField();
        jtfDescricaoD.setSize(150, 60); //definição de tamanho
        jtfDescricaoD.setLocation(10,65); //localização
        pnlCadProd.add(jtfDescricaoD); //inserindo formulario
        
        //Unidade
        JLabel jlblUni = new JLabel();
        jlblUni.setSize(160, 15); //definição de tamanho
        jlblUni.setLocation(200,90); //localização
        jlblUni.setFont(arialBold_16);
        jlblUni.setText("Unidade: "); //definição texto
        pnlCadProd.add(jlblUni); //inserindo formulario
        //Entrada Nome
        JTextField jtfUnidadeD = new JTextField();
        jtfUnidadeD.setSize(145, 20); //definição de tamanho
        jtfUnidadeD.setLocation(200,105); //localização
        pnlCadProd.add(jtfUnidadeD); //inserindo formulario      
              
        //Quantidade
        JLabel jlblQuant = new JLabel();
        jlblQuant.setSize(100, 15); //definição de tamanho
        jlblQuant.setLocation(200,10); //localização
        jlblQuant.setFont(arialBold_16);
        jlblQuant.setText("Quantidade: "); //definição texto
        pnlCadProd.add(jlblQuant); //inserindo formulario
        //Entrada Nome
        JTextField jtfQuantidadeD = new JTextField();
        jtfQuantidadeD.setSize(145, 20); //definição de tamanho
        jtfQuantidadeD.setLocation(200,25); //localização
        pnlCadProd.add(jtfQuantidadeD); //inserindo formulario
        
        //Preço
        JLabel jlblPrec = new JLabel();
        jlblPrec.setSize(100, 15); //definição de tamanho
        jlblPrec.setLocation(200,50); //localização
        jlblPrec.setFont(arialBold_16);
        jlblPrec.setText("Preço: "); //definição texto
        pnlCadProd.add(jlblPrec); //inserindo formulario
        //Entrada Nome
        JTextField jtfPrecoD = new JTextField();
        jtfPrecoD.setSize(145, 20); //definição de tamanho
        jtfPrecoD.setLocation(200,65); //localização
        pnlCadProd.add(jtfPrecoD); //inserindo formulario
        
        
        
        //Apagar Produto
        JButton btnApagarProd = new JButton(); //criação botão
        btnApagarProd.setSize(100, 20); //tamanho
        btnApagarProd.setLocation(400,25); //localização
        btnApagarProd.setText("Apagar"); //definição texto
        pnlCadProd.add(btnApagarProd); //inserindo botão
        
        //Salvar Produto
        JButton btnSaveProd = new JButton(); //criação botão
        btnSaveProd.setSize(100, 20); //tamanho
        btnSaveProd.setLocation(400,65); //localização
        btnSaveProd.setText("Salvar"); //definição texto
        pnlCadProd.add(btnSaveProd); //inserindo botão        
        
      /////////////////////////////////////////////////////////////////////////
      
      
      ///Fornecedor
                
      //Painel com barra de rolagem
      JScrollPane pnlScrlTbForn;
      
      //Tabel da Clientes
      JTable tblForn;
      
      //vetor com os titulos das colunas da tabela
      String[] colTbForn = {"Código", "Empresa", "Contato", "Telefone", "Email"};
      
      //Vetor com o dados da Tabela
      String [] [] dadosTbForn = {
          {"0001", "Empresa", "Contato", "Telefone", "teste1@gmail.com"},          
          {"0002", "Empresa", "Contato", "Telefone", "teste2@gmail.com"},          
          {"0003", "Empresa", "Contato", "Telefone", "teste3@gmail.com"},          
          {"0004", "Empresa", "Contato", "Telefone", "teste4@gmail.com"},          
          {"0005", "Empresa", "Contato", "Telefone", "teste5@gmail.com"},          
          {"0006", "Empresa", "Contato", "Telefone", "teste6@gmail.com"},          
          {"0007", "Empresa", "Contato", "Telefone", "teste7@gmail.com"},          
          {"0008", "Empresa", "Contato", "Telefone", "teste8@gmail.com"},          
      };
      
      //Preencha a tabela com os dados e nomes das colunas
      tblForn = new JTable(dadosTbForn, colTbForn);
      
      //Adiciona a tabela ao painel de rolagem
      pnlScrlTbForn = new JScrollPane (tblForn);
      
      ///Definições Tamanho, localização e adição
      pnlScrlTbForn.setSize(530,118);
      pnlScrlTbForn.setLocation(5,5);
      pnlForn.add(pnlScrlTbForn);
      
      //////////////////////////////////////////////////////////////////////////
      
      //Criar painel de cadrasto Produtos
      JPanel pnlCadForn = new JPanel();
      pnlCadForn.setSize(530, 135);
      pnlCadForn.setLocation(5, 130);
      
      
      
      //Coloca borda azul no painel
      pnlCadForn.setBorder(brdBlue);
      pnlCadForn.setLayout(null);
      pnlForn.add(pnlCadForn);
      
      //////////////////////////////////////////////////////////////////////////
      
        //Código
        JLabel jlblCodForn = new JLabel();
        jlblCodForn.setSize(160, 15); //definição de tamanho
        jlblCodForn.setLocation(10,10); //localização
        jlblCodForn.setFont(arialBold_16);
        jlblCodForn.setText("Código: "); //definição texto
        pnlCadForn.add(jlblCodForn); //inserindo formulario
        //Entrada Codigo
        JTextField jtfCodigoFornD = new JTextField();
        jtfCodigoFornD.setSize(150, 20); //definição de tamanho
        jtfCodigoFornD.setLocation(10,25); //localização
        pnlCadForn.add(jtfCodigoFornD); //inserindo formulario
        
        
        //Empresa
        JLabel jlblEmpre = new JLabel();
        jlblEmpre.setSize(160, 15); //definição de tamanho
        jlblEmpre.setLocation(10,50); //localização
        jlblEmpre.setFont(arialBold_16);
        jlblEmpre.setText("Empresa: "); //definição texto
        pnlCadForn.add(jlblEmpre); //inserindo formulario
        //Entrada Nome
        JTextField jtfEmpresaD = new JTextField();
        jtfEmpresaD.setSize(150, 20); //definição de tamanho
        jtfEmpresaD.setLocation(10,65); //localização
        pnlCadForn.add(jtfEmpresaD); //inserindo formulario
        
        //Contato
        JLabel jlblCont = new JLabel();
        jlblCont.setSize(160, 15); //definição de tamanho
        jlblCont.setLocation(10,90); //localização
        jlblCont.setFont(arialBold_16);
        jlblCont.setText("Contato: "); //definição texto
        pnlCadForn.add(jlblCont); //inserindo formulario
        //Entrada Nome
        JTextField jtfContatoD = new JTextField();
        jtfContatoD.setSize(335, 20); //definição de tamanho
        jtfContatoD.setLocation(10,105); //localização
        pnlCadForn.add(jtfContatoD); //inserindo formulario      
              
        //Telefone
        JLabel jlblTelefone = new JLabel();
        jlblTelefone.setSize(100, 15); //definição de tamanho
        jlblTelefone.setLocation(200,10); //localização
        jlblTelefone.setFont(arialBold_16);
        jlblTelefone.setText("Telefone: "); //definição texto
        pnlCadForn.add(jlblTelefone); //inserindo formulario
        //Entrada Nome
        JTextField jtfTelefonD = new JTextField();
        jtfTelefonD.setSize(145, 20); //definição de tamanho
        jtfTelefonD.setLocation(200,25); //localização
        pnlCadForn.add(jtfTelefonD); //inserindo formulario
        
        //Email
        JLabel jlblEmailForn = new JLabel();
        jlblEmailForn.setSize(100, 15); //definição de tamanho
        jlblEmailForn.setLocation(200,50); //localização
        jlblEmailForn.setFont(arialBold_16);
        jlblEmailForn.setText("Email: "); //definição texto
        pnlCadForn.add(jlblEmailForn); //inserindo formulario
        //Entrada Nome
        JTextField jtfEmailFornD = new JTextField();
        jtfEmailFornD.setSize(145, 20); //definição de tamanho
        jtfEmailFornD.setLocation(200,65); //localização
        pnlCadForn.add(jtfEmailFornD); //inserindo formulario
        
        
        //Apagar Produto
        JButton btnApagarForn = new JButton(); //criação botão
        btnApagarForn.setSize(100, 20); //tamanho
        btnApagarForn.setLocation(400,25); //localização
        btnApagarForn.setText("Apagar"); //definição texto
        pnlCadForn.add(btnApagarForn); //inserindo botão
        
        //Salvar Produto
        JButton btnSaveForn = new JButton(); //criação botão
        btnSaveForn.setSize(100, 20); //tamanho
        btnSaveForn.setLocation(400,65); //localização
        btnSaveForn.setText("Salvar"); //definição texto
        pnlCadForn.add(btnSaveForn); //inserindo botão
      
      
      frm.repaint();
    }
 
    
}
