/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagerenciamento;

import javax.swing.JFrame;

/**
 *
 * @author gabriel_piske
 */
public class FormPrincipal extends JFrame {

    public FormPrincipal() {
        super();
        setSize(400, 350);
        setLocation(100, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setTitle("Sistema de Gerenciamento Inteligente");
        setVisible(true);
    }
}
